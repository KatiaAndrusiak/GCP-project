import base64
import json
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import functions_framework
from google.cloud import storage

storage_client = storage.Client()

@functions_framework.cloud_event
def send_email_notification(cloud_event):
    pubsub_message = base64.b64decode(cloud_event.data["message"]["data"]).decode('utf-8')

    bucket_name = 'emails-sender-data'
    blob_name_emails = 'emails.txt'
    blob_name_content = 'content.txt'

    bucket = storage_client.get_bucket(bucket_name)
    blob_emails = bucket.blob(blob_name_emails).download_as_string().decode("utf-8") 
    blob_content = bucket.blob(blob_name_content)
    if blob_content.exists():  
        downloaded_file = blob_content.download_as_string().decode("utf-8") 

        message = Mail(
            from_email='andrusiak@student.agh.edu.pl',
            to_emails=blob_emails.splitlines(),
            subject='Inspiration for a great day!',
            html_content=downloaded_file)
        try:
            sg = SendGridAPIClient('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')
            response = sg.send(message)
            print(response.status_code)
            print(response.body)
            print(response.headers)
            if response.status_code == 202:
                blob_content.delete()
                print(f"Blob {blob_content} deleted.")

        except Exception as e:
            print(e)
    else:
        print(f"There is no content to send. Blob {blob_content} does not exist.")

    print(pubsub_message)


